# Operational Analysis Pipeline

Reference document for the new **Operational Analysis** area (replacement for the current `Analise profunda` placeholder at [src/pages/AnaliseProfunda.tsx](../src/pages/AnaliseProfunda.tsx)).

This is the conceptual source of truth. The endpoint contracts and KPI map described here are scheduled for future phases; no production SQL query is included in this document (same "placeholder mode" pattern used in [missing-endpoints-contracts.md](missing-endpoints-contracts.md)).

---

## 1. Context and Scope

The current dashboard ([Index.tsx](../src/pages/Index.tsx), [ComparacaoAgentes.tsx](../src/pages/ComparacaoAgentes.tsx), [AnaliseProdutividade.tsx](../src/pages/AnaliseProdutividade.tsx), [DetalhamentoAgentes.tsx](../src/pages/DetalhamentoAgentes.tsx)) operates strictly on a **same-day window** (global rule `@Hoje <= data < @Amanha`, see [mapa-kpis-dashboard.md](mapa-kpis-dashboard.md)). It answers "how are we performing now?" and is designed for immediate operational response.

**Operational Analysis** is a parallel (non-replacement) layer for medium-term decisions:

- Long window horizon (weeks / months / years).
- Multi-factor cuts (agent × portfolio × hour × weekday × month).
- Pattern detection rather than isolated-event reporting.
- Action-oriented outputs (coaching, reallocation, alerts), not only descriptive metrics.

### Naming Note

"Operational Analysis" partially overlaps with current pages that are also operational. The business team selected this name to emphasize that the intended output is **operational guidance** (coaching, reallocation, prioritization), not data science exploration. Considered alternatives: "Historical Analysis", "Operational Intelligence", "Strategic Analysis". Final naming remains pending (see section 8).

### Explicit Boundary

This area **does not** replace existing pages. If the user needs same-day status, `Index` remains the correct entry point. Operational Analysis is intended for questions that require a window broader than one day.

### Cross-Document Reference

The same-day dashboard redesign is defined in [redesign_executivo_dashboard.plan.md](redesign_executivo_dashboard_92b7d68c_plan.md). Both documents share the same metric dictionary and must be versioned together. Navigation architecture connecting both is defined in that document's "Cross-Document Reference" section.

---

## 2. Three-Level Model (analytical pyramid)

Adapted from the classical analytical pyramid (Gartner) to the collections domain:

| Level | Question answered | Collections-domain example |
|---|---|---|
| **Descriptive** | "What happened?" | "We closed 50 agreements from 500 contacts in the month" |
| **Diagnostic** | "Why did it happen?" | "Conversion drops 30% after 4 PM; agent X has 0% conversion for 5 days" |
| **Prescriptive** | "What should we do?" | "Reallocate afternoon agents, coach X, prioritize portfolio Y" |

The fourth classical level (Predictive — "what will happen?") is **out of initial scope**. Statistical/ML models are only considered in roadmap phase 5 if ROI is justified.

### UI Organization

All three levels are presented as **vertical sections within the same page**, ordered by reasoning flow (descriptive -> diagnostic -> prescriptive), instead of separate tabs. Rationale: a single reading flow naturally connects "what", "why", and "what to do". Tab separation would fragment this reasoning path.

---

## 3. KPI Map by Analytical Level

Format follows [mapa-kpis-dashboard.md](mapa-kpis-dashboard.md). Production queries remain as `TODO: BUSINESS_QUERY_REQUIRED` until business validation.

### 3.1 Descriptive

| KPI | Conceptual formula | Temporal aggregation | Proposed endpoint | Primary source |
|---|---|---|---|---|
| `acionamentos_serie` | `COUNT(DISTINCT ID_CTO_MASTER)` by period | day / week / month | `/dashboard/operacional/descritivo/{db}` | `CTO_MASTER` |
| `contatos_serie` | `COUNT(DISTINCT ID_CTO_MASTER WHERE CPC)` by period | day / week / month | same | `CTO_MASTER` |
| `cpc_historico` | `contatos_serie / acionamentos_serie * 100` | day / week / month | same | derived |
| `acordos_serie` | `COUNT(DISTINCT NR_RECEBIMENTO WHERE approved)` by period | day / week / month | same | `REC_MASTER` |
| `valor_acordos_serie` | `SUM(valor_total_acordo WHERE approved)` by period | day / week / month | same | `REC_MASTER` |
| `ticket_medio_historico` | `AVG(valor_total_acordo WHERE approved)` by period | month | same | `REC_MASTER` |
| `taxa_conversao_historica` | `acordos_serie / acionamentos_serie * 100` | day / week / month | same | derived |
| `excecoes_serie` | `COUNT(DISTINCT NR_RECEBIMENTO WHERE status=11)` | day / week / month | same | `REC_MASTER` |
| `primeira_parcela_serie` | `SUM(VALOR WHERE PARCELA=0 AND approved)` | day / week / month | same | `REC_MASTER` |
| `desconto_medio_historico` | `AVG(valor_total_acordo / VR_ORIGINAL * 100)` | month | same | `REC_MASTER` + `REC_DIVIDAS` + `DIV_MASTER` |

### 3.2 Diagnostic

| KPI / Slice | Question answered | Proposed endpoint | Source |
|---|---|---|---|
| `conversao_por_hora` | "At which hours do we convert better/worse?" | `/dashboard/operacional/diagnostico/{db}?corte=hora` | `CTO_MASTER` + `REC_MASTER` |
| `conversao_por_dia_semana` | "Is Monday weaker than Friday?" | `/dashboard/operacional/diagnostico/{db}?corte=dia_semana` | `CTO_MASTER` + `REC_MASTER` |
| `agentes_fora_da_media` | "Who is consistently below baseline?" | `/dashboard/operacional/diagnostico/{db}?corte=agente` | `CTO_MASTER` + `REC_MASTER` + `USU_MASTER` |
| `portfolios_em_queda` | "Which portfolios are losing performance?" | `/dashboard/operacional/diagnostico/{db}?corte=portfolio` | `REC_MASTER` + `DIV_AUX.CAMPO010` |
| `comparativo_mes_vs_mes` | "Current month vs previous month?" | `/dashboard/operacional/diagnostico/{db}?corte=mes_vs_mes` | aggregated fact |
| `sazonalidade_primeira_parcela` | "On which days is first-installment concentration highest?" | `/dashboard/operacional/diagnostico/{db}?corte=sazonalidade` | `REC_MASTER` |
| `correlacao_esforco_conversao` | "Does increased effort convert into agreements?" | `/dashboard/operacional/diagnostico/{db}?corte=correlacao` | derived |
| `dispersao_agentes` | "How large is cross-agent variance?" | `/dashboard/operacional/diagnostico/{db}?corte=dispersao` | `CTO_MASTER` + `USU_MASTER` |
| `comparativo_bu` | "How do AUTOS and CONSUMER diverge over time?" | `/dashboard/operacional/diagnostico/{db}?corte=bu` | aggregated fact |
| `eficiencia_marginal_agente` | "At what effort level does conversion start declining per agent?" | `/dashboard/operacional/diagnostico/{db}?corte=eficiencia_marginal` | derived |
| `cohort_tenure` | "How do new agents (< 30d) perform vs veterans?" | `/dashboard/operacional/diagnostico/{db}?corte=cohort` | `USU_MASTER` + aggregated fact |

**Anomaly detection** (optional, advanced phase 3): simple z-score style flag (for example, values outside ±2σ over a 30-day moving baseline). No ML in initial scope.

**Drift detection** (phase 3): comparison of current-window mean vs previous-window mean with significance test (two-sample t-test or Welch's test). If `p < 0.05`, flag the metric as `drifting`. This feeds prescriptive rules directly (e.g., `alerta_portfolio_em_risco` can use drift detection instead of a fixed 20% threshold).

### 3.3 Prescriptive

Rules are **deterministic and auditable**. Each rule follows: condition -> severity -> recommended action.

| Rule | Condition | Severity | Recommended action |
|---|---|---|---|
| `flag_coaching_agente` | Agent with >= N daily attempts and 0% conversion for 3 consecutive days | high | Immediate one-on-one coaching |
| `sinal_realocacao_turno` | Conversion drop > 30% after 4 PM for >= 5 business days | medium | Reallocate afternoon capacity or review contact timing |
| `alerta_portfolio_em_risco` | Portfolio with >= 20% agreement decline month-over-month (or drift detection p < 0.05) | high | Review portfolio strategy and contact policy |
| `excesso_excecoes_agente` | Agent with `qtd_excecoes / qtd_acordos > X%` in month window | medium | Exception policy audit |
| `desconto_fora_do_padrão` | Agent average discount > 1.5x office baseline | medium | Discount authority review |
| `baixo_aproveitamento_cpc` | Agent with high CPC and low conversion | medium | Closing-skills coaching |
| `concentracao_primeira_parcela` | > 80% first-installment concentration in < 20% of agents | low | Portfolio redistribution |
| `eficiencia_marginal_saturada` | Agent consistently above marginal-efficiency threshold with declining conversion | medium | Reduce daily target or redistribute contacts |

Parameters `N`, `X`, window sizes, and thresholds should be externalized in a **separate configuration asset** (not hardcoded) so business can tune behavior without deployment. See section 4.4 for configuration contract.

---

## 4. Data Pipeline

```mermaid
flowchart LR
    src[("CTO_MASTER, REC_MASTER, USU_MASTER, DIV_AUX, DIV_MASTER")]
    job["Daily Aggregation Job"]
    fato[("fato_produtividade_dia")]
    api["Historical FastAPI Endpoints"]
    cache["In-memory Cache (short TTL)"]
    rules["Prescriptive Rules Engine"]
    alerts[("Active Alerts Table")]
    fe["Operational Analysis Page"]

    src --> job --> fato
    fato --> api --> cache --> fe
    fato --> rules --> alerts --> fe
```

### 4.1 Stage Rationale

- **Daily aggregation job**: running 12+ month queries directly on `CTO_MASTER` / `REC_MASTER` is not operationally viable (latency + source DB load). The job runs once per day, outside business peak.
- **Fact table `fato_produtividade_dia`**: minimum grain is day × agent × portfolio × database. This enables arbitrary slicing without re-reading raw transactional tables. Size estimate: ~28 months × ~X agents × ~Y portfolios (manageable footprint).
- **Historical endpoints**: read **only** from fact layer, never from raw sources, ensuring predictable API latency.
- **In-memory cache (short TTL)**: repeated access to same windows justifies 5–15 minute TTL to reduce repeated computation.
- **Prescriptive rules engine**: isolated from descriptive endpoint; consumes fact layer, applies section 3.3 rules, persists alerts.
- **Active alerts table**: persistent state with timestamps, status (`active` / `resolved` / `ignored`), and severity for auditability and historical review.

### 4.2 Source -> Target Mapping

| Source | Relevant fields | Fact-layer target |
|---|---|---|
| `CTO_MASTER` | `ID_CTO_MASTER`, `ID_COMPLEMENTO`, `DATA`, agente | `qtd_acionamentos`, `qtd_contatos` |
| `REC_MASTER` | `NR_RECEBIMENTO`, `ID_REC_STATUS`, `PLANO`, `PARCELA`, `VALOR` | `qtd_acordos`, `qtd_excecoes`, `valor_acordos`, `valor_primeira_parcela` |
| `REC_DIVIDAS` + `DIV_MASTER` | `VR_ORIGINAL`, `VR_SALDO` | `desconto_medio` |
| `DIV_AUX.CAMPO010` | portfolio | portfolio dimension |
| `USU_MASTER` | `CHAVE`, name, `DT_CADASTRO` (if available) | agent dimension + tenure |

### 4.3 Inherited Exclusion Rules

Preserve current backend exclusion rules ([main.py](../../main.py)): agents `COBDESANTOS`, `NEMBUSUSER`, and prefixes `ANTLIA%` / `INTERNA%`. These exclusions must run in the **aggregation job** (not in read-time queries) to keep outputs consistent across pages.

### 4.4 Rules Configuration Contract

Prescriptive rule parameters must be externalized. This section defines the schema.

**Recommended approach:** YAML file at `backend/rules/operacional.yaml`, loaded at FastAPI startup and reloaded on SIGHUP or via admin endpoint.

```yaml
# backend/rules/operacional.yaml
version: 1
rules:
  flag_coaching_agente:
    enabled: true
    min_daily_attempts: 50          # N
    zero_conversion_consecutive_days: 3
    severity: high

  sinal_realocacao_turno:
    enabled: true
    conversion_drop_threshold_pct: 30
    hour_cutoff: 16                 # 4 PM
    min_business_days: 5
    severity: medium

  alerta_portfolio_em_risco:
    enabled: true
    decline_threshold_pct: 20
    use_drift_detection: false      # toggle to true when drift detection is implemented
    drift_p_value: 0.05
    severity: high

  excesso_excecoes_agente:
    enabled: true
    exception_rate_threshold_pct: 15  # X
    window_days: 30
    severity: medium

  desconto_fora_do_padrao:
    enabled: true
    multiplier_vs_baseline: 1.5
    severity: medium

  baixo_aproveitamento_cpc:
    enabled: true
    cpc_threshold_pct: 40            # "high CPC" = above this
    conversion_threshold_pct: 5      # "low conversion" = below this
    severity: medium

  concentracao_primeira_parcela:
    enabled: true
    agent_pct_threshold: 20          # < 20% of agents
    value_pct_threshold: 80          # > 80% of value
    severity: low

  eficiencia_marginal_saturada:
    enabled: true
    min_data_points: 10              # minimum days to calculate
    conversion_decline_pct: 20       # marginal decline threshold
    severity: medium
```

**Access pattern:**
- Rules engine loads config at startup.
- `GET /admin/rules-config` returns current active configuration (read-only, requires admin auth).
- `POST /admin/rules-config/reload` forces reload from file (admin auth).
- Future: migrate to database table for UI-based editing.

**Versioning:** The `version` field increments on any change. Rules engine logs the active version on every run for auditability.

### 4.5 Data Freshness Contract

The response envelope for all historical endpoints must include a `freshness` field in `meta`:

```json
{
  "meta": {
    "generated_at": "ISO-8601",
    "last_aggregation_at": "ISO-8601",  // NEW: when the fact table was last updated
    "freshness_status": "fresh|stale",  // NEW: "stale" if last_aggregation_at > 26 hours ago
    "total_rows": 0,
    "sources": ["fato_produtividade_dia"],
    "filters": {}
  },
  "data": [],
  "errors": []
}
```

**Frontend behavior:**
- If `freshness_status === "stale"`, show a yellow banner: "Dados atualizados até {last_aggregation_at}. Agregação diária pode estar pendente."
- If `last_aggregation_at` is null or missing, show: "Status de atualização indisponível."

### 4.6 Alert Lifecycle

Alerts in `alertas_operacional` follow a state machine:

```
[new] → ativo → resolvido
                ↘ ignorado

Transitions:
- ativo → resolvido: AUTOMATIC when the triggering condition is no longer true
                      on the next rules engine run.
- ativo → ignorado:  MANUAL by manager via UI action ("dismiss alert").
- ignorado → ativo:  NOT allowed. Once ignored, stays ignored for that instance.
                      A new alert is created if the condition re-triggers.
```

**Retention policy:** Resolved and ignored alerts are retained for 90 days (configurable in `operacional.yaml`), then archived or deleted by a cleanup job. Active alerts are never auto-deleted.

---

## 5. Endpoint Contracts

Following the same "placeholder mode" pattern defined in [missing-endpoints-contracts.md](missing-endpoints-contracts.md). SQL remains `TODO: BUSINESS_QUERY_REQUIRED`.

### 5.1 Descriptive

- **Endpoint**: `GET /dashboard/operacional/descritivo/{database_name}`
- **Purpose**: Long-window time series for primary KPIs.
- **Query Placeholder**: `TODO: BUSINESS_QUERY_REQUIRED`

**Query params**:
- `start_date` (required, `YYYY-MM-DD`)
- `end_date` (required, `YYYY-MM-DD`)
- `interval` (optional, default `month`: `day | week | month`)
- `assessoria` (optional)

**Response contract**:
```json
{
  "meta": {
    "generated_at": "ISO-8601",
    "last_aggregation_at": "ISO-8601",
    "freshness_status": "fresh|stale",
    "total_rows": 0,
    "sources": ["fato_produtividade_dia"],
    "filters": {
      "start_date": "YYYY-MM-DD",
      "end_date": "YYYY-MM-DD",
      "interval": "month",
      "assessoria": "string"
    }
  },
  "data": [
    {
      "period": "YYYY-MM",
      "qtd_acionamentos": 0,
      "qtd_contatos": 0,
      "cpc_percentual": 0.0,
      "qtd_acordos": 0,
      "valor_acordos": 0.0,
      "taxa_conversao": 0.0,
      "ticket_medio": 0.0,
      "qtd_excecoes": 0,
      "valor_primeira_parcela": 0.0,
      "desconto_medio_percentual": 0.0
    }
  ],
  "errors": []
}
```

Note: there is intentional overlap with `/dashboard/produtividade-historico/{db}` already defined in [missing-endpoints-contracts.md](missing-endpoints-contracts.md). Pending decision: **unify** into a single endpoint (preferred) or **keep both**. If unified, this endpoint becomes the canonical one and the other should be removed from backlog.

### 5.2 Diagnostic

- **Endpoint**: `GET /dashboard/operacional/diagnostico/{database_name}`
- **Purpose**: Cross-sectional views explaining descriptive-level variation.
- **Query Placeholder**: `TODO: BUSINESS_QUERY_REQUIRED`

**Query params**:
- `start_date` (required)
- `end_date` (required)
- `corte` (required: `hora | dia_semana | agente | portfolio | mes_vs_mes | sazonalidade | correlacao | dispersao | bu | eficiencia_marginal | cohort`)
- `assessoria` (optional)

**Response contract** (`data` shape may vary by `corte`; envelope remains stable):
```json
{
  "meta": {
    "generated_at": "ISO-8601",
    "last_aggregation_at": "ISO-8601",
    "freshness_status": "fresh|stale",
    "total_rows": 0,
    "sources": ["fato_produtividade_dia"],
    "filters": {
      "start_date": "YYYY-MM-DD",
      "end_date": "YYYY-MM-DD",
      "corte": "hora",
      "assessoria": "string"
    }
  },
  "data": [
    {
      "dimensao_label": "string",
      "dimensao_valor": "string",
      "qtd_acionamentos": 0,
      "qtd_contatos": 0,
      "qtd_acordos": 0,
      "taxa_conversao": 0.0,
      "desvio_vs_media": 0.0,
      "drift_detected": false
    }
  ],
  "errors": []
}
```

#### Specific `corte=bu` response shape

When `corte=bu`, the response contains one row per BU per period, enabling direct comparison:

```json
{
  "data": [
    {
      "dimensao_label": "AUTOS",
      "dimensao_valor": "COBwebRCBAUTOS",
      "period": "YYYY-MM",
      "qtd_acionamentos": 0,
      "qtd_contatos": 0,
      "qtd_acordos": 0,
      "valor_acordos": 0.0,
      "valor_primeira_parcela": 0.0,
      "taxa_conversao": 0.0,
      "cpc_percentual": 0.0,
      "ticket_medio": 0.0,
      "desvio_vs_media": 0.0
    }
  ]
}
```

#### Specific `corte=eficiencia_marginal` response shape

When `corte=eficiencia_marginal`, the response contains binned data per agent:

```json
{
  "data": [
    {
      "agente": "string",
      "faixa_acionamentos": "0-20",
      "taxa_conversao_media": 0.0,
      "n_dias": 0,
      "ponto_saturacao_estimado": 85
    }
  ]
}
```

`ponto_saturacao_estimado` is the acionamento count at which conversion starts declining (derived from inflection point in the binned curve). `null` if insufficient data.

#### Specific `corte=cohort` response shape

```json
{
  "data": [
    {
      "cohort": "novo|intermediario|veterano",
      "cohort_label": "< 30 dias | 30–90 dias | > 90 dias",
      "qtd_agentes": 0,
      "media_acionamentos": 0.0,
      "media_conversao": 0.0,
      "media_valor_acordos": 0.0,
      "media_cpc": 0.0
    }
  ]
}
```

### 5.3 Prescriptive

- **Endpoint**: `GET /dashboard/operacional/prescritivo/{database_name}`
- **Purpose**: Return active alerts/recommendations generated by the rules engine.
- **Query Placeholder**: `TODO: RULES_ENGINE_PENDING`

**Query params**:
- `severidade` (optional: `alta | media | baixa`)
- `status` (optional, default `ativo`: `ativo | resolvido | ignorado`)
- `assessoria` (optional)

**Response contract**:
```json
{
  "meta": {
    "generated_at": "ISO-8601",
    "total_rows": 0,
    "sources": ["alertas_operacional"],
    "filters": {
      "severidade": "alta",
      "status": "ativo"
    }
  },
  "data": [
    {
      "alerta_id": "string",
      "regra": "flag_coaching_agente",
      "severidade": "alta",
      "status": "ativo",
      "titulo": "string",
      "descricao": "string",
      "acao_sugerida": "string",
      "entidade_tipo": "agente|portfolio|escritorio",
      "entidade_id": "string",
      "entidade_nome": "string",
      "metrica_gatilho": 0.0,
      "criado_em": "ISO-8601",
      "dados_referencia": {
        "link_diagnostico": "string"
      }
    }
  ],
  "errors": []
}
```

The `dados_referencia.link_diagnostico` field points to the diagnostic endpoint that supports the rule trigger, enabling inverse drill-up navigation (prescriptive -> diagnostic) in UI.

### 5.4 Alert State Transition

- **Endpoint**: `PATCH /dashboard/operacional/prescritivo/{database_name}/alertas/{alerta_id}`
- **Purpose**: Allow manager to dismiss (ignore) an alert.
- **Body**: `{ "status": "ignorado" }`
- **Auth**: Requires admin-level auth (same as existing `x-api-key` + `Authorization`).

---

## 6. Interface Proposal

Target page: `src/pages/AnaliseOperacional.tsx`.

### 6.1 Page Structure

```
+---------------------------------------------------------------+
| Header: "Operational Analysis" + SidebarTrigger               |
+---------------------------------------------------------------+
| Sticky filters:                                                |
|   [ Period: Current month / 3m / 6m / 12m / Custom ]          |
|   [ Database: All / AUTOS / CONSUMER ]                        |
|   [ Assessoria: optional ]                                    |
+---------------------------------------------------------------+
| Freshness banner (conditional — only if stale)                 |
+---------------------------------------------------------------+
| Section 1 - DESCRIPTIVE ("What happened?")                    |
|   Period-aggregated KPI cards                                 |
|   Time-series chart (line + composed bars)                    |
|   Current-vs-previous period comparison                       |
+---------------------------------------------------------------+
| Section 2 - DIAGNOSTIC ("Why did it happen?")                 |
|   Internal tabs by slice: Hour | Weekday | Agent |            |
|                   Portfolio | Month-over-month | Correlation | |
|                   BU Comparison | Marginal Efficiency | Cohort |
|   Chart + table for selected slice                            |
|   Outlier highlight (± 2 sigma)                               |
+---------------------------------------------------------------+
| Section 3 - PRESCRIPTIVE ("What should we do?")               |
|   Alert list grouped by severity                              |
|   Each card: title + description + suggested action +         |
|              "view diagnostic" button (inverse drill-up) +    |
|              "dismiss" button (→ ignorado)                     |
+---------------------------------------------------------------+
```

### 6.2 Visual Encoding Specification (Operational Analysis charts)

#### Descriptive — Time Series

| Attribute | Value |
|---|---|
| **Chart type** | `ComposedChart` (Recharts) |
| **X axis** | Period labels (months, weeks, or days depending on `interval`) |
| **Bars** | `valor_acordos` (green-600) + `valor_primeira_parcela` (green-400), stacked |
| **Lines** | `taxa_conversao` (amber-500, right Y axis %) + `cpc_percentual` (amber-300, right Y axis %) |
| **Y axis left** | BRL (financial bars) |
| **Y axis right** | Percentage (efficiency lines) |
| **Why ComposedChart** | Time-series with two unit types. Bars show absolute financial volume per period; lines overlay efficiency trends. Dual Y axes are acceptable here because X is a shared time dimension (unlike categorical bars where dual axes mislead). |

#### Descriptive — Current vs Previous Period

| Attribute | Value |
|---|---|
| **Chart type** | `BarChart` — **Grouped bars** |
| **X axis** | KPI names (acionamentos, contatos, acordos, valor_acordos, etc.) |
| **Y axis** | Normalized to % change (or raw values if same unit) |
| **Bars** | 2 per KPI: `previous` (muted, opacity 50%) + `current` (full color) |
| **Labels** | Delta annotation above current bar: `+12%` or `-8%` |
| **Why grouped** | Direct visual comparison of same metric across two periods. |

#### Diagnostic — corte=hora

| Attribute | Value |
|---|---|
| **Chart type** | `BarChart` — **Vertical bars** |
| **X axis** | Hours (8h–18h or operational range) |
| **Y axis** | `taxa_conversao` (%) |
| **Bars** | 1 per hour (amber-500) |
| **Reference line** | Daily average (dashed) |
| **Anomaly highlight** | Bars outside ±2σ get red-500 fill |
| **Why bar chart** | Discrete categories (hours), not continuous. Line would imply interpolation between hours. |

#### Diagnostic — corte=dia_semana

| Attribute | Value |
|---|---|
| **Chart type** | `BarChart` — **Vertical bars** |
| **X axis** | Weekdays (Seg–Sex) |
| **Y axis** | `taxa_conversao` (%) |
| **Bars** | 1 per day (amber-500), anomalies highlighted in red-500 |
| **Reference line** | Weekly average (dashed) |

#### Diagnostic — corte=agente (outliers)

| Attribute | Value |
|---|---|
| **Chart type** | `BarChart` — **Horizontal bars** |
| **Orientation** | Horizontal (`layout="vertical"`) |
| **Y axis** | Agent names, sorted by `desvio_vs_media` ascending (worst first) |
| **X axis** | `desvio_vs_media` (%) — negative = below average |
| **Bars** | Diverging: green for positive deviation, red for negative |
| **Reference line** | Zero line (office average) |
| **Why diverging horizontal** | Immediately shows who is above/below average. Agent names need horizontal space. |

#### Diagnostic — corte=portfolio (decline)

| Attribute | Value |
|---|---|
| **Chart type** | `BarChart` — **Horizontal bars** |
| **Y axis** | Portfolio names (`APELIDO`), sorted by decline magnitude |
| **X axis** | % change month-over-month |
| **Bars** | Diverging: green for growth, red for decline |
| **Drift flag** | If `drift_detected === true`, show 🔴 icon next to portfolio name |

#### Diagnostic — corte=bu (BU Comparison over time)

| Attribute | Value |
|---|---|
| **Chart type** | `ComposedChart` — **Dual line chart** |
| **X axis** | Period (months) |
| **Lines** | 2 lines: AUTOS (solid blue-600) + CONSUMER (solid blue-400) |
| **Y axis left** | Primary metric (toggle: `valor_acordos` / `taxa_conversao` / `cpc`) |
| **Interaction** | Metric selector dropdown above chart to toggle Y axis metric |
| **Why dual lines** | Shows trend divergence between BUs over time. Bars would clutter with many periods. |
| **Supplementary** | Below the line chart, a small grouped bar chart showing the selected period's absolute values side-by-side (same pattern as Home Page BU Outcome). |

#### Diagnostic — corte=correlacao (effort vs conversion)

| Attribute | Value |
|---|---|
| **Chart type** | `ScatterChart` |
| **X axis** | `qtd_acionamentos` (effort) |
| **Y axis** | `taxa_conversao` (%) |
| **Dots** | 1 per agent-day, color-coded by BU |
| **Trend line** | Optional LOESS/moving-average overlay (computed in frontend from binned data) |
| **Why scatter** | Reveals whether more effort actually converts. Cluster patterns become visible. |

#### Diagnostic — corte=eficiencia_marginal

| Attribute | Value |
|---|---|
| **Chart type** | `ComposedChart` — **Bar + Line** |
| **X axis** | `faixa_acionamentos` bins (0-20, 20-40, ...) |
| **Bars** | `n_dias` count per bin (blue-300, contextual) |
| **Line** | `taxa_conversao_media` per bin (amber-500) |
| **Vertical reference line** | `ponto_saturacao_estimado` (dashed red) |
| **Why composed** | Bars show data density per bin (confidence indicator); line shows the efficiency curve. The reference line marks where diminishing returns start. |

#### Diagnostic — corte=dispersao

| Attribute | Value |
|---|---|
| **Chart type** | `BoxPlot` (custom — Recharts doesn't have native box plots; use `ComposedChart` with `ErrorBar` or a custom SVG component) |
| **X axis** | Metric name or BU |
| **Y axis** | Metric value |
| **Elements** | Median line, Q1-Q3 box, whiskers at 1.5×IQR, outlier dots |
| **Why box plot** | Directly answers "how large is cross-agent variance" — shows distribution shape, not just average. |

#### Diagnostic — corte=cohort

| Attribute | Value |
|---|---|
| **Chart type** | `BarChart` — **Grouped bars** |
| **X axis** | 3 cohorts: Novo (< 30d), Intermediário (30–90d), Veterano (> 90d) |
| **Y axis** | Selected metric (toggle: conversion / CPC / valor_acordos) |
| **Bars** | 1 per cohort, color gradient from light to dark |
| **Labels** | `qtd_agentes` shown as annotation below each group |
| **Why grouped** | Direct comparison across tenure groups for any metric. |

#### Prescriptive — Alert List

| Attribute | Value |
|---|---|
| **Chart type** | Not a chart — structured card list |
| **Grouping** | By severity: alta (top, red border-left) → media (amber) → baixa (blue) |
| **Card contents** | Title, description, `acao_sugerida`, entity name, `metrica_gatilho` value |
| **Actions** | "Ver diagnóstico" button (scrolls to diagnostic section with pre-filter) + "Ignorar" button |
| **Empty state** | "Nenhum alerta ativo. Operação dentro dos parâmetros." |

### 6.3 UX Rules

- **Fixed order** (descriptive -> diagnostic -> prescriptive): enforces analytical reasoning flow; no top-level tab split.
- **Inverse drill-up**: each prescriptive alert links back to supporting diagnostic view. Example: selecting `flag_coaching_agente:AGT_123` scrolls to diagnostic section pre-filtered for that agent.
- **Reuse existing filter model**: `DatabaseOption` selection is reused (see [AnaliseProdutividade.tsx](../src/pages/AnaliseProdutividade.tsx) and related pages).
- **Incremental loading**: each section loads independently; prescriptive block can render before descriptive completes.
- **Explicit empty states**: each section displays clear no-data/no-alert states.
- **Freshness banner**: shown at page top when `freshness_status === "stale"`. Dismissible per session.

### 6.4 Reusable Components

Reuse existing components where feasible:

- `DashboardV2ChartsPanel` as visual baseline for chart style.
- `AnaliseChartsPanel` as structural baseline for diagnostic slices.
- Types and helper functions from `src/services/api.ts`.
- `ExecutiveKpiStrip` from redesign plan for descriptive KPI cards (same component, reused).
- `SectionHeader` from redesign plan for section titles.

---

## 7. Implementation Roadmap

| Phase | Scope | Deliverables | Dependencies |
|---|---|---|---|
| **0** | Conceptual (this doc) | `pipeline-analise-operacional.md` approved | — |
| **1** | Descriptive backend | `fato_produtividade_dia` table + aggregation job + `/operacional/descritivo/{db}` endpoint + freshness metadata | SQL Agent (or equivalent scheduler) access |
| **2** | Descriptive frontend | Rename `AnaliseProfunda.tsx` -> `AnaliseOperacional.tsx`; update route in [App.tsx](../src/App.tsx) and sidebar label in [AppSidebar.tsx](../src/components/AppSidebar.tsx); implement descriptive section with ComposedChart + period comparison | Phase 1 complete |
| **3** | Diagnostic | `/operacional/diagnostico/{db}` endpoint (all cortes including bu, eficiencia_marginal, cohort) + `DiagnosticoChartsPanel` component with chart types per Visual Encoding spec | Phase 1 (fact table) |
| **3b** | Drift detection | Statistical comparison module in rules engine; `drift_detected` flag in diagnostic response | Phase 3 |
| **4** | Prescriptive | Rules engine (YAML config + job) + `alertas_operacional` table + alert lifecycle (auto-resolve, manual dismiss) + `/operacional/prescritivo/{db}` endpoint + alerts UI + inverse drill-up | Phase 3 (diagnostic as reference) |
| **5** *(optional)* | Statistical/ML evolution | Short-term forecasting, model-based anomaly detection | ROI validation after phase 4 |

Each phase is independently valuable. By the end of phase 2, the area already delivers meaningful value (navigable historical analysis) without requiring later phases.

---

## 8. Open Decisions

The following items require definition before or during implementation:

1. **Final area name**: "Operational Analysis" vs alternatives ("Historical Analysis", "Operational Intelligence", "Strategic Analysis"). This affects sidebar label and route naming.
2. **Actual historical depth available**: [data-coverage-analysis.md](data-coverage-analysis.md) states "28 months + 15 days". Validate with DBA before exposing long windows in UI.
3. **Unification with `/produtividade-historico/{db}`**: keep both endpoints or unify into `/operacional/descritivo/{db}`? Recommended: unify.
4. **Final prescriptive rule set**: section 3.3 provides a baseline; business must confirm what is in v1.
5. **Rule parameters**: initial values for `N`, `X`, windows, and thresholds. See section 4.4 for schema; business must provide initial values.
6. **Aggregation job runtime**: SQL Agent, Python cron inside FastAPI, or external scheduler? This affects operational ownership.
7. **Fact-table granularity**: is day × agent × portfolio × database sufficient? Is day × agent × portfolio × **hour** required for `conversao_por_hora`? If yes, volume grows ~24x.
8. **Alert retention policy**: initial proposal is 90 days for resolved/ignored (section 4.6). Business confirmation needed.
9. **Agent tenure source**: Does `USU_MASTER` have a `DT_CADASTRO` or equivalent for cohort analysis? If not, tenure must be derived from first-appearance in `CTO_MASTER`.
10. **BoxPlot implementation**: Recharts lacks native box plots. Options: (a) custom SVG component, (b) use d3 within a Recharts-compatible wrapper, (c) approximate with ErrorBar. Decision affects phase 3 effort.

---

## 9. References

- [mapa-kpis-dashboard.md](mapa-kpis-dashboard.md) — KPIs of the current same-day operational dashboard.
- [missing-endpoints-contracts.md](missing-endpoints-contracts.md) — contract pattern used in this document.
- [data-coverage-analysis.md](data-coverage-analysis.md) — data coverage and gap analysis.
- [refactor_main_py_report.md](refactor_main_py_report.md) — current backend status.
- [redesign_executivo_dashboard.plan.md](redesign_executivo_dashboard_92b7d68c_plan.md) — same-day executive dashboard redesign (shared metric dictionary and navigation architecture).
- [../src/pages/AnaliseProfunda.tsx](../src/pages/AnaliseProfunda.tsx) — current placeholder that will be renamed in phase 2.
